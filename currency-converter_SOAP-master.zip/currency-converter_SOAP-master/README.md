# currency-converter_SOAP

used web Service: http://fx.cloanto.com/webservices/CloantoCurrencyServer.asmx?WSDL

Simple Gui:

<img src="https://github.com/fay3r/currency-converter_SOAP/blob/master/image/1.png?raw=true" width="360" height="190">
